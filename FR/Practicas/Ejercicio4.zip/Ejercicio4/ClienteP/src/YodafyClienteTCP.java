
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress; 

public class YodafyClienteTCP {

	public static void main(String[] args) {
		
		int puerto=8989;
		InetAddress direccion;
		DatagramPacket paquete, paqueteRecepcion;
		byte []buferEnvio = new byte[256];
		byte []buferRecepcion = new byte[256];
		DatagramSocket socket;
		String fraseYodificada;
		
		try {
			
			socket = new DatagramSocket();
			direccion = InetAddress.getByName("localhost");
			
			
			buferEnvio = "Al monte del volcán debes ir sin demora".getBytes();
			
			
			paquete = new DatagramPacket(buferEnvio, buferEnvio.length, direccion, puerto);
			fraseYodificada = new String(paquete.getData());
			socket.send(paquete);
			paqueteRecepcion = new DatagramPacket(buferRecepcion, buferRecepcion.length);
			socket.receive(paqueteRecepcion);
			fraseYodificada = new String(paqueteRecepcion.getData());
			System.out.println("Contenido del paquete recibido: " + fraseYodificada );
			
			socket.close();
			
		} catch (UnknownHostException e) {
			System.err.println("Error: Nombre de host no encontrado.");
		} catch (IOException e) {
			System.err.println("Error de entrada/salida al abrir el socket.");
		}
	}
}