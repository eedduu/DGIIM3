import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.DatagramSocket;
import java.net.DatagramPacket;

public class YodafyServidorIterativo {

	public static void main(String[] args) {
	
		// Puerto de escucha
		int port=8989;
		// array de bytes auxiliar para recibir o enviar datos.
		byte []buferEnvio=new byte[256];
		byte []buferRecepcion=new byte[256];
		// Número de bytes leídos
		int bytesLeidos=0;

		// Socket del servidor
		DatagramSocket socketServicio;
		DatagramPacket paquete, paqueteModificado;
		
		try {

			socketServicio = new DatagramSocket(port);


			// Mientras ... siempre!
			do {
				paquete = new DatagramPacket(buferRecepcion, buferRecepcion.length);

				System.out.println("Esperando sockets...");
			
				try {
					socketServicio.receive(paquete);
					ProcesadorYodafy procesador=new ProcesadorYodafy(paquete);
					procesador.procesa();
					paqueteModificado = new DatagramPacket(buferEnvio, buferEnvio.length, paquete.getAddress(), paquete.getPort());

					socketServicio.send(paqueteModificado);
				} catch (IOException e) {
					System.err.println("Error: no se pudo aceptar la conexion solicitada");
				}


			} while (true);

		} catch (IOException e) {
			System.err.println("Error al escuchar en el puerto "+port);
		}

	}

}